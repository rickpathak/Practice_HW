package com.java.virtusa.day1;

public class Data {

    public void sayHello() {
        System.out.println("Hello World...");
    }

    private void trainer() {
        System.out.println("Trainer is Prasanna...");
    }

    void company() {
        System.out.println("Company is Virtusa...");
    }
}
