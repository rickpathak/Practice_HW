package com.java.virtusa.day1;

import java.util.Scanner;

public class Prog2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name;
        System.out.println("Enter your name  ");
        name = sc.nextLine();
        System.out.println("Name is " +name);
    }
}
