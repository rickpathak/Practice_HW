// Write a program to display a number from (1 to 9999) in rowman format
// Day - 2

package Practice;
import java.util.Scanner;

public class NumbertoRoman {
    public static String toRoman(int number) {
        if (number <= 0 || number > 9999) {
            return "Number must be between 1 and 9999";
        }

        String[] romanLetters = {
                "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"
        };
        int[] values = {
                1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1
        };

        StringBuilder roman = new StringBuilder();

        for (int i = 0; i < values.length; i++) {
            while (number >= values[i]) {
                number -= values[i];
                roman.append(romanLetters[i]);
            }
        }

        return roman.toString();
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a number (1–9999): ");
        int num = input.nextInt();

        String roman = toRoman(num);
        System.out.println("Roman numeral: " + roman);

        input.close();
    }
}
