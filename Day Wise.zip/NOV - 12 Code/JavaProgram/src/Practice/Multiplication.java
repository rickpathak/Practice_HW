// Write a Program to print multiplication of 2 numbers (100 digit * 100 digit i want exact value dont use BigInt class)

// Day -2
package Practice;

import java.util.Scanner;

public class Multiplication {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter first 100-digit number:");
        String num1 = sc.nextLine();

        System.out.println("Enter second 100-digit number:");
        String num2 = sc.nextLine();

        sc.close();

        String product = multiplyStrings(num1, num2);
        System.out.println("Product:\n" + product);
    }


    public static String multiplyStrings(String num1, String num2) {
        if (num1.equals("0") || num2.equals("0"))
            return "0";


        String result = "0";

        int numZeros = 0;
        for (int i = num2.length() - 1; i >= 0; i--) {
            int digit2 = num2.charAt(i) - '0';
            StringBuilder partial = new StringBuilder();


            for (int z = 0; z < numZeros; z++)
                partial.append('0');

            int carry = 0;
            for (int j = num1.length() - 1; j >= 0; j--) {
                int digit1 = num1.charAt(j) - '0';
                int product = digit1 * digit2 + carry;
                partial.append(product % 10);
                carry = product / 10;
            }

            if (carry > 0)
                partial.append(carry);


            partial.reverse();


            result = addStrings(result, partial.toString());
            numZeros++;
        }


        while (result.length() > 1 && result.charAt(0) == '0')
            result = result.substring(1);

        return result;
    }

    // Helper function to add two large numbers as strings
    public static String addStrings(String num1, String num2) {
        StringBuilder sb = new StringBuilder();

        int i = num1.length() - 1;
        int j = num2.length() - 1;
        int carry = 0;

        while (i >= 0 || j >= 0 || carry > 0) {
            int sum = carry;
            if (i >= 0) sum += num1.charAt(i--) - '0';
            if (j >= 0) sum += num2.charAt(j--) - '0';
            sb.append(sum % 10);
            carry = sum / 10;
        }

        return sb.reverse().toString();
    }
}
