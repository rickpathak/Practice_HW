

public class Quiz7 {
    public static void main(String[] args) {
        String s1="Shalli",s2="Lokesh",s3="Meghana",s4="Shalli";
        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());
        System.out.println(s3.hashCode());
        System.out.println(s4.hashCode());
    }
}
