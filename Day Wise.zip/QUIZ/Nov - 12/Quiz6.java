

public class Quiz6 {

    public static void main(String[] args) {
        String str = "Hello";
        System.out.println(str.concat(" World"));
        System.out.println(str);
    }
}
