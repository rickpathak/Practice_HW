
public class Quiz1 {
    public static void main(String[] args) {
        int ch='A';
        System.out.println(ch);
    }
}
