


public class Quiz7 {

    public static void main(String[] args) {
        String s1="Hello", s2="Hello";
        System.out.println(s1==s2);
        System.out.println(s1.equals(s2));
    }
}

// What is the diff between == and equals()

