
// Every class in Java extends the base class Object (directly or indirectly).
// So anything that’s created from a class — like String, Integer, Float, Scanner, etc. — is an Object.

// byte  ->	 Byte
// short ->	 Short
// int	 ->  Integer
// long	 ->  Long
// float ->  Float
// double -> Double
// char	 ->  Character
// boolean -> Boolean

public class Quiz2 {

    public void show(Object ob) {
        if (ob=="ABC") {
            System.out.println("Correct");
        } else {
            System.out.println("Wrong");
        }
    }

    public static void main(String[] args) {
        String str="ABC";
        // Quiz2 ss = new Quiz2();          // this also right
        // ss.show(str);                    // not creating Reference Variable
        new Quiz2().show(str);
    }
}
