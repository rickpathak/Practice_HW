package com.java.abs;

public class Anusri extends Training {

    @Override
    public void name() {
        System.out.println("Hi I am Anusri");
    }

    @Override
    public void email() {
     System.out.println("Email is anu@gmail.com");
    }
}
