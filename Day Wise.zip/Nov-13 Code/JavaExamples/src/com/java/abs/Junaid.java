package com.java.abs;

import com.java.sup.Employ;

public class Junaid extends Employ {

    public Junaid(int empno, String name, double basic) {
        super(empno, name, basic);
    }
}
