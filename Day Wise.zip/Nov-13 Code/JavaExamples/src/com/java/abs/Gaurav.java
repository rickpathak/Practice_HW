package com.java.abs;

import com.java.sup.Employ;

public class Gaurav extends Employ {

    public Gaurav(int empno, String name, double basic) {
        super(empno, name, basic);
    }
}
