package com.java.sup;

public class Karthik extends Employ {
    public Karthik(int empno, String name, double basic) {
        super(empno, name, basic);
    }
}
