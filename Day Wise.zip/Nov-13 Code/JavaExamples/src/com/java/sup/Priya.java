package com.java.sup;

public class Priya extends Employ {
    public Priya(int empno, String name, double basic) {
        super(empno, name, basic);
    }
}
