package com.java.solid;

public class EmployMain {
    public static void main(String[] args) {

    }
}
