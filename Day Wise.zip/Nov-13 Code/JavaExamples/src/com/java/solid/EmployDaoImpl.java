package com.java.solid;

public class EmployDaoImpl implements EmployDao {
    @Override
    public Employ[] showEmployDao() {
        return new Employ[0];
    }

    @Override
    public String addEmployDao(Employ employ) {
        return "";
    }
}
