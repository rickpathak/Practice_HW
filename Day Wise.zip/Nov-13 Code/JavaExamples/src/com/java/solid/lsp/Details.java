package com.java.solid.lsp;

public abstract class Details {
    abstract void showInfo();
}
