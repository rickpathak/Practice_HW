package com.java.solid;

public interface EmployDao {
    Employ[] showEmployDao();
    String addEmployDao(Employ employ);
}
